"use client"

import React, { useState, useEffect } from "react"
import { X, Trophy, TrendingUp, Users, Clock, Rocket, Star, Zap, Flame } from 'lucide-react'
import { motion } from "framer-motion"

// Import your AviatorGame component
// Note: We're using a dynamic import pattern that works with React
const AviatorGame = React.lazy(() => import("./AviatorGame"))

// List of Indian names
const indianNames = [
  "Aarav", "Arjun", "Advait", "Bhavesh", "Chirag", "Darshan", "Eshan", 
  "Farhan", "Gaurav", "Harsh", "Ishaan", "Jai", "Kabir", "Lakshay", 
  "Mohit", "Neeraj", "Omkar", "Pranav", "Rahul", "Siddharth", 
  "Tarun", "Ujjwal", "Vivek", "Yash", "Zain"
];

function HomePage({ setShowNavbar }) {
  const [activeGame, setActiveGame] = useState(null)
  const [winners, setWinners] = useState([])
  const [liveUsers, setLiveUsers] = useState(0)
  const [totalWinnings, setTotalWinnings] = useState(0)
  const [rocketPosition, setRocketPosition] = useState(0)
  const [multiplier, setMultiplier] = useState(1.00)
  const [isRocketCrashed, setIsRocketCrashed] = useState(false)
  const [showCrashText, setShowCrashText] = useState(false)
  const [particles, setParticles] = useState([])

  useEffect(() => {
    // Generate particles for the crash game card
    const newParticles = [];
    for (let i = 0; i < 20; i++) {
      newParticles.push({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 3 + 1,
        speed: Math.random() * 0.5 + 0.2,
      });
    }
    setParticles(newParticles);

    // Animate the rocket and multiplier
    const rocketInterval = setInterval(() => {
      setRocketPosition(prev => {
        if (prev >= 100) {
          setIsRocketCrashed(true);
          setShowCrashText(true);
          setTimeout(() => {
            setIsRocketCrashed(false);
            setShowCrashText(false);
            setMultiplier(1.00);
            return 0;
          }, 2000);
          return 100;
        }
        
        // Increase multiplier as rocket moves
        if (prev > 0 && prev < 100) {
          setMultiplier(prev => {
            const newValue = 1 + (prev - 1) + (Math.random() * 0.05);
            return Math.min(parseFloat(newValue.toFixed(2)), 5.00);
          });
        }
        
        return prev + 1;
      });
    }, 100);

    // Generate random winners with Indian names
    const generateWinners = () => {
      const newWinners = [];
      for (let i = 0; i < 15; i++) {
        const randomName = indianNames[Math.floor(Math.random() * indianNames.length)];
        const winAmount = Math.floor(Math.random() * 990) + 10; // Between 10 and 1000
        const game = Math.random() > 0.7 ? "Lucky Slots" : "Cosmic Crash";
        const timeAgo = Math.floor(Math.random() * 59) + 1;
        
        newWinners.push({
          id: i,
          name: randomName,
          amount: winAmount,
          game: game,
          timeAgo: timeAgo
        });
      }
      setWinners(newWinners);
    };

    // Set random stats
    setLiveUsers(Math.floor(Math.random() * 500) + 1500);
    setTotalWinnings(Math.floor(Math.random() * 50000) + 100000);
    
    generateWinners();
    
    // Refresh winners every 30 seconds
    const winnersInterval = setInterval(() => {
      generateWinners();
    }, 30000);
    
    return () => {
      clearInterval(winnersInterval);
      clearInterval(rocketInterval);
    };
  }, []);

  const handleGameClick = (gameId) => {
    setActiveGame(gameId)
    setShowNavbar(false)
  }

  const handleCloseGame = () => {
    setActiveGame(null)
    setShowNavbar(true)
  }

  // Featured games data - only two games as requested
  const featuredGames = [
    {
      id: "aviator",
      title: "Cosmic Crash",
      description: "Bet and cash out before the rocket crashes!",
      imageSrc: "/placeholder.jpg",
      status: "live",
      type: "crash"
    },
    {
      id: "slots",
      title: "Treasure Hunt",
      description: "Discover hidden treasures and win big prizes!",
      imageSrc: "/placeholder.jpg",
      status: "coming-soon",
      type: "slots"
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-indigo-950 to-black text-white">
      {/* Full-screen game when active */}
      {activeGame && (
        <div
          className="fixed inset-0 z-50 bg-black"
          style={{
            opacity: 1,
            transition: "opacity 0.3s ease-in-out",
          }}
        >
          <button
            onClick={handleCloseGame}
            className="absolute top-4 right-4 z-50 bg-gray-800 p-2 rounded-full hover:bg-gray-700 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>

          <React.Suspense
            fallback={
              <div className="flex items-center justify-center h-screen bg-black">
                <div className="w-16 h-16 border-4 border-t-blue-500 border-blue-500/30 rounded-full animate-spin"></div>
              </div>
            }
          >
            {activeGame === "aviator" && <AviatorGame />}
            {/* Add other games here with similar conditional rendering */}
          </React.Suspense>
        </div>
      )}

      {/* Main content when no game is active */}
      {!activeGame && (
        <div className="container mx-auto px-4 py-8">
          {/* Games section - MOVED TO TOP */}
          <section className="mb-12">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400 flex items-center">
                <Zap className="w-8 h-8 mr-2 text-yellow-400" />
                Our Games
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {featuredGames.map((game) => (
                <motion.div 
                  key={game.id}
                  className={`relative group overflow-hidden rounded-2xl border-2 ${game.type === 'crash' ? 'border-blue-500/50' : 'border-indigo-500/30'} shadow-lg transition-all duration-300 hover:-translate-y-2 ${game.type === 'crash' ? 'crash-game-card' : ''}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                  whileHover={{ scale: 1.02 }}
                  onClick={() => game.status !== "coming-soon" && handleGameClick(game.id)}
                >
                  {/* Background with animated gradient */}
                  <div className={`absolute inset-0 ${game.type === 'crash' ? 'bg-gradient-animated' : 'bg-gradient-to-br from-blue-900/80 to-purple-900/80'} z-10`}></div>
                  
                  {/* Background image */}
                  <div className="absolute inset-0 bg-[url('/placeholder.jpg')] bg-cover bg-center group-hover:scale-110 transition-transform duration-500 opacity-30"></div>
                  
                  {/* Particles for crash game */}
                  {game.type === 'crash' && particles.map(particle => (
                    <div 
                      key={`particle-${particle.id}`}
                      className="absolute rounded-full bg-white z-20 opacity-70"
                      style={{
                        left: `${particle.x}%`,
                        top: `${particle.y}%`,
                        width: `${particle.size}px`,
                        height: `${particle.size}px`,
                        animation: `floatParticle ${10/particle.speed}s linear infinite`
                      }}
                    />
                  ))}
                  
                  {game.type === 'crash' && (
                    <>
                      {/* Rocket animation path */}
                      <div className="absolute inset-0 z-20 overflow-hidden">
                        <svg className="absolute w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                          <defs>
                            <linearGradient id="pathGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                              <stop offset="0%" stopColor="#3b82f6" />
                              <stop offset="100%" stopColor="#06b6d4" />
                            </linearGradient>
                          </defs>
                          <path 
                            d="M 10,90 Q 50,10 90,90" 
                            fill="none" 
                            stroke="url(#pathGradient)" 
                            strokeWidth="2"
                            strokeDasharray="3,3"
                            className="path-glow"
                          />
                        </svg>
                        
                        {/* Animated rocket */}
                        <motion.div 
                          className={`absolute w-12 h-12 z-30 rocket-animation ${isRocketCrashed ? 'rocket-crash' : ''}`}
                          style={{
                            left: `${10 + (rocketPosition * 0.8)}%`,
                            top: `${90 - Math.sin(rocketPosition * 0.03) * 80}%`,
                            transform: 'translate(-50%, -50%) rotate(-45deg)'
                          }}
                          animate={isRocketCrashed ? {
                            scale: [1, 1.5, 0],
                            rotate: ['-45deg', '45deg', '180deg'],
                            opacity: [1, 1, 0]
                          } : {}}
                          transition={{ duration: 1, ease: "easeOut" }}
                        >
                          <div className="relative">
                            <div className="absolute inset-0 bg-blue-500 rounded-full filter blur-md opacity-50 animate-pulse"></div>
                            <Rocket className="w-12 h-12 text-white relative z-10" />
                            <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 w-6 h-8 z-0">
                              <div className="w-full h-full relative">
                                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-3 h-6 bg-gradient-to-t from-orange-500 via-yellow-400 to-transparent rounded-full animate-flame"></div>
                                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-4 h-4 bg-gradient-to-t from-red-500 via-orange-400 to-transparent rounded-full animate-flame-slow"></div>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      </div>
                      
                      {/* Game type badge */}
                      <div className="absolute top-4 left-4 z-20 bg-gradient-to-r from-blue-600 to-cyan-600 px-3 py-1 rounded-full text-white font-bold text-sm flex items-center shadow-glow">
                        <Flame className="w-4 h-4 mr-1 text-yellow-300" />
                        CRASH GAME
                      </div>
                      
                      {/* Multiplier display */}
                      <motion.div 
                        className={`absolute bottom-24 right-6 z-20 bg-gradient-to-r from-green-500 to-green-600 px-4 py-2 rounded-lg text-white font-bold text-2xl ${isRocketCrashed ? 'hidden' : 'animate-pulse-fast'}`}
                        animate={{ scale: [1, 1.1, 1] }}
                        transition={{ duration: 0.5, repeat: Infinity }}
                      >
                        {multiplier.toFixed(2)}x
                      </motion.div>
                      
                      {/* Crash text */}
                      {showCrashText && (
                        <motion.div 
                          className="absolute bottom-24 left-1/2 transform -translate-x-1/2 z-30"
                          initial={{ scale: 0, rotate: -10 }}
                          animate={{ scale: 1, rotate: 0 }}
                          transition={{ duration: 0.3, type: "spring" }}
                        >
                          <div className="bg-gradient-to-r from-red-600 to-red-700 px-6 py-3 rounded-lg text-white font-bold text-3xl shadow-lg border-2 border-red-400 transform rotate-3">
                            CRASH!
                          </div>
                        </motion.div>
                      )}
                    </>
                  )}
                  
                  <div className="relative z-20 p-6 h-full flex flex-col justify-between">
                    {game.status === "coming-soon" && (
                      <div className="absolute top-4 right-4 bg-gradient-to-r from-yellow-500 to-amber-500 text-black text-xs font-bold px-3 py-1 rounded-full flex items-center shadow-md">
                        <Clock className="w-3 h-3 mr-1" />
                        COMING SOON
                      </div>
                    )}
                    
                    <div>
                      <h3 className="text-3xl font-bold mb-2 flex items-center">
                        {game.title}
                        <Star className="w-5 h-5 ml-2 text-yellow-400 animate-pulse-slow" />
                      </h3>
                      <p className="text-gray-300 mb-4 text-lg">{game.description}</p>
                      
                      {game.type === 'crash' && (
                        <div className="bg-black/40 p-4 rounded-lg mb-4 border border-blue-500/30 shadow-inner">
                          {/* <p className="text-base text-gray-300">
                            <span className="font-bold text-blue-400 block mb-1">How to play:</span> 
                            Place your bet, watch the multiplier increase, and cash out before the rocket crashes to win!
                          </p> */}
                        </div>
                      )}
                    </div>
                    
                    <motion.button
                      className={`${
                        game.status === "coming-soon" 
                          ? "bg-gray-700 cursor-not-allowed" 
                          : "bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                      } text-white px-6 py-4 rounded-lg font-bold text-lg shadow-lg transition-all duration-300`}
                      disabled={game.status === "coming-soon"}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      {game.status === "coming-soon" ? "Coming Soon" : "Play Now"}
                    </motion.button>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>

          {/* Hero section with animated background */}
          <section className="mb-12 relative overflow-hidden">
            <div className="absolute inset-0 bg-blue-900 opacity-20">
              <div className="stars"></div>
              <div className="twinkling"></div>
              <div className="shooting-stars"></div>
            </div>
            
            <motion.div
              className="bg-gradient-to-r from-blue-900 to-purple-900 rounded-2xl p-6 md:p-10 relative overflow-hidden border-2 border-indigo-500/30 shadow-[0_0_25px_rgba(79,70,229,0.4)]"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <div className="absolute inset-0 bg-[url('/placeholder.jpg')] bg-cover opacity-20 mix-blend-overlay"></div>
              <div className="relative z-10">
                <motion.h1 
                  className="text-4xl md:text-6xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400"
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  Gaming Paradise
                </motion.h1>
                <motion.p 
                  className="text-lg md:text-xl text-gray-300 mb-6 max-w-2xl"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.6 }}
                >
                  Experience the thrill of our premium games with amazing graphics and big rewards!
                </motion.p>
                <motion.button
                  className="bg-gradient-to-r from-purple-600 to-blue-600 text-white px-8 py-4 rounded-full font-bold text-lg shadow-lg hover:shadow-purple-500/20"
                  onClick={() => handleGameClick("aviator")}
                  whileHover={{ scale: 1.05, boxShadow: "0 0 20px rgba(147, 51, 234, 0.5)" }}
                  whileTap={{ scale: 0.95 }}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.8 }}
                >
                  Play Now
                </motion.button>
              </div>
            </motion.div>
          </section>

          {/* Stats section */}
          <section className="mb-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { 
                icon: Users, 
                label: "Live Users", 
                value: liveUsers.toLocaleString(), 
                color: "blue",
                delay: 0.1
              },
              { 
                icon: TrendingUp, 
                label: "Total Winnings", 
                value: `₹${totalWinnings.toLocaleString()}`, 
                color: "green",
                delay: 0.2
              },
              { 
                icon: Trophy, 
                label: "Top Prize", 
                value: "₹25,000", 
                color: "purple",
                delay: 0.3
              }
            ].map((stat, index) => (
              <motion.div 
                key={index}
                className={`bg-gradient-to-br from-gray-800 to-gray-900 p-6 rounded-xl border-2 border-${stat.color}-500/30 shadow-lg flex items-center hover:shadow-${stat.color}-500/20 hover:-translate-y-1 transition-all duration-300`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: stat.delay }}
                whileHover={{ scale: 1.03 }}
              >
                <div className={`bg-${stat.color}-500/20 p-3 rounded-full mr-4`}>
                  <stat.icon className={`w-6 h-6 text-${stat.color}-400`} />
                </div>
                <div>
                  <p className="text-gray-400 text-sm">{stat.label}</p>
                  <p className="text-2xl font-bold">{stat.value}</p>
                </div>
              </motion.div>
            ))}
          </section>

          {/* Recent winners */}
          <section>
            <motion.h2 
              className="text-3xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400 flex items-center"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Trophy className="w-8 h-8 mr-2 text-yellow-400" />
              Recent Winners
            </motion.h2>

            <motion.div 
              className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl border-2 border-indigo-500/30 shadow-lg p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="overflow-hidden" style={{ height: "400px" }}>
                <div className="winners-scroll">
                  {winners.map((winner) => (
                    <div key={winner.id} className="flex items-center justify-between py-4 border-b border-gray-700/50 hover:bg-gray-800/50 rounded-lg px-2 transition-colors">
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full mr-4 flex items-center justify-center text-white font-bold text-lg shadow-md">
                          {winner.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-medium text-lg">{winner.name}</div>
                          <div className="text-sm text-gray-400 flex items-center">
                            {winner.game === "Cosmic Crash" ? (
                              <Rocket className="w-3 h-3 mr-1 text-blue-400" />
                            ) : (
                              <Star className="w-3 h-3 mr-1 text-yellow-400" />
                            )}
                            {winner.game} • {winner.timeAgo} min ago
                          </div>
                        </div>
                      </div>
                      <div className="text-green-400 font-bold text-lg">₹{winner.amount.toLocaleString()}</div>
                    </div>
                  ))}
                  
                  {/* Duplicate the winners for seamless scrolling */}
                  {winners.map((winner) => (
                    <div key={`dup-${winner.id}`} className="flex items-center justify-between py-4 border-b border-gray-700/50 hover:bg-gray-800/50 rounded-lg px-2 transition-colors">
                      <div className="flex items-center">
                        <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full mr-4 flex items-center justify-center text-white font-bold text-lg shadow-md">
                          {winner.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-medium text-lg">{winner.name}</div>
                          <div className="text-sm text-gray-400 flex items-center">
                            {winner.game === "Cosmic Crash" ? (
                              <Rocket className="w-3 h-3 mr-1 text-blue-400" />
                            ) : (
                              <Star className="w-3 h-3 mr-1 text-yellow-400" />
                            )}
                            {winner.game} • {winner.timeAgo} min ago
                          </div>
                        </div>
                      </div>
                      <div className="text-green-400 font-bold text-lg">₹{winner.amount.toLocaleString()}</div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>

            <style jsx="true">{`
              @keyframes scrollWinners {
                0% { transform: translateY(0); }
                100% { transform: translateY(-50%); }
              }
              
              .winners-scroll {
                animation: scrollWinners 30s linear infinite;
              }
              
              .stars {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                width: 100%;
                height: 100%;
                background: transparent;
                background-image: radial-gradient(white, rgba(255, 255, 255, 0.2) 2px, transparent 2px);
                background-size: 100px 100px;
              }
              
              .twinkling {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                width: 100%;
                height: 100%;
                animation: twinkle 8s linear infinite;
              }
              
              .shooting-stars::before, .shooting-stars::after {
                content: "";
                position: absolute;
                width: 100px;
                height: 2px;
                background: linear-gradient(to right, rgba(0,0,0,0), rgba(255,255,255,0.8), rgba(0,0,0,0));
                border-radius: 50%;
                animation: shooting-star 6s linear infinite;
                top: 0;
                transform: rotate(45deg);
              }
              
              .shooting-stars::after {
                animation-delay: 3s;
                top: 30%;
                width: 80px;
              }
              
              @keyframes shooting-star {
                0% {
                  transform: translateX(-100%) translateY(0) rotate(45deg);
                  opacity: 1;
                }
                70% {
                  opacity: 1;
                }
                100% {
                  transform: translateX(200%) translateY(300%) rotate(45deg);
                  opacity: 0;
                }
              }
              
              @keyframes twinkle {
                from { opacity: 0.5; }
                50% { opacity: 1; }
                to { opacity: 0.5; }
              }
              
              @keyframes flame {
                0%, 100% { height: 6px; opacity: 0.8; }
                50% { height: 10px; opacity: 1; }
              }
              
              @keyframes flame-slow {
                0%, 100% { height: 4px; opacity: 0.6; }
                50% { height: 8px; opacity: 0.8; }
              }
              
              .animate-flame {
                animation: flame 0.3s ease-in-out infinite;
              }
              
              .animate-flame-slow {
                animation: flame-slow 0.5s ease-in-out infinite;
              }
              
              .animate-pulse-fast {
                animation: pulse 0.8s ease-in-out infinite;
              }
              
              .animate-pulse-slow {
                animation: pulse 3s ease-in-out infinite;
              }
              
              @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.7; }
              }
              
              .crash-game-card {
                box-shadow: 0 0 30px rgba(59, 130, 246, 0.5);
              }
              
              .rocket-animation {
                transition: all 0.05s linear;
              }
              
              .rocket-crash {
                animation: explode 1s forwards;
              }
              
              @keyframes explode {
                0% { transform: translate(-50%, -50%) rotate(-45deg) scale(1); opacity: 1; }
                50% { transform: translate(-50%, -50%) rotate(20deg) scale(1.5); opacity: 0.8; }
                100% { transform: translate(-50%, -50%) rotate(45deg) scale(0.1); opacity: 0; }
              }
              
              .path-glow {
                filter: drop-shadow(0 0 3px #3b82f6);
              }
              
              .shadow-glow {
                box-shadow: 0 0 10px rgba(59, 130, 246, 0.7);
              }
              
              @keyframes floatParticle {
                0% { transform: translateY(0) scale(1); opacity: 0.7; }
                50% { transform: translateY(-20px) scale(1.2); opacity: 0.9; }
                100% { transform: translateY(-40px) scale(0.8); opacity: 0; }
              }
              
              .bg-gradient-animated {
                background: linear-gradient(-45deg, #1e3a8a, #1e40af, #0d4b6e, #0f172a);
                background-size: 400% 400%;
                animation: gradient 15s ease infinite;
              }
              
              @keyframes gradient {
                0% { background-position: 0% 50%; }
                50% { background-position: 100% 50%; }
                100% { background-position: 0% 50%; }
              }
            `}</style>
          </section>
        </div>
      )}
    </div>
  )
}

export default HomePage
